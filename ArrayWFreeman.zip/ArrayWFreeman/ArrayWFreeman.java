import java.util.*;
import java.util.Scanner;

public class ArrayWFreeman
{
  private int arrayWF[] = new int[20];
  private int value;

  public int storeWF(){
    Scanner kb = new Scanner(System.in);
    for(int i = 0; i < 10; i ++)
    {
      System.out.println("Enter a value for element #" + i);
      value = kb.nextInt();
      arrayWF[i] = value;
    }
    return 0;
  }

  public int printWF(){
    System.out.println("\n============================== \n\n");
    System.out.println("Print out all values of array");
    for(int i = 0; i < 10; i ++)
    {
      System.out.println(arrayWF[i]);
    }
    return 0;
  }

  public int printEvenWF(){
    System.out.println("\n============================== \n\n");
    System.out.println("Print all even values of array");
    for(int i = 0; i < 10; i ++)
    {
      if((arrayWF[i] % 2) == 0)
      {
        System.out.println(arrayWF[i]);
      }
    }
    return 0;
  }

  public int printOddWF(){
    System.out.println("\n============================== \n\n");
    System.out.println("Print all odd values in array");
    for(int i = 0; i < 10; i ++){
      if((arrayWF[i] % 2) != 0){
        System.out.println(arrayWF[i]);
      }
    }
    return 0;
  }

  public int searchArrayWF(){
    System.out.println("\n============================== \n\n");
    System.out.println("Search array for a value");
    Scanner kb = new Scanner(System.in);
    System.out.println("Search: ");
    int ele = kb.nextInt();
    System.out.println("");
    System.out.println("searching...");
    boolean search;

    for(int i = 0; i < 10; i ++){
      if(arrayWF[i] == ele){
        search = true;
        System.out.println("Data found");
        break;
      } else if(arrayWF[i] == 9){
        search = false;
        System.out.println("Data not found");
        break;
      }
    }
    return 0;
  }
}
